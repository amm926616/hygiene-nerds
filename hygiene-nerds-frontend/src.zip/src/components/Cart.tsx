
export default function Cart() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">Your Cart</h2>
      {/* Cart items will be rendered here */}
      <p>Your cart is currently empty.</p>
    </div>
  );
};

