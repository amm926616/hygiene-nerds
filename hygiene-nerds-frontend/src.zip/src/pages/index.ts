export { default as About } from "./About";
export { default as CartPage } from "./CartPage";
export { default as Contact } from "./Contact";
export { default as Home } from "./Home";
export { default as Products } from "./Products";
